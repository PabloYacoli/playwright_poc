/* global jQuery */

jQuery(document).ready(($) => {
  $('.nav-btn').on('click', (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    const wasActive = $(ev.currentTarget).hasClass('active');
    $('.nav-btn').removeClass('active');
    $('.menu .sub-menu').slideUp();
    if (!wasActive) {
      $(ev.currentTarget).toggleClass('active');
      $(ev.currentTarget).find('+ .sub-menu').slideDown();
    }
  });

  // close navbar when clicking outside of it
  $(document).on('click', (ev) => {
    if ($(ev.currentTarget).closest('.main-nav').length === 0) {
      $('.nav-btn').removeClass('active');
      $('.menu .sub-menu').slideUp();
    }
  });

  $('.mobile-menu .drop-down-menu li .droplist').click((ev) => {
    $(ev.currentTarget)
      .parent()
      .next()
      .slideToggle()
      .siblings('div')
      .slideUp();
    return false;
  });

  const searchbar = $('#desktop-searchbar');

  // Hide header icons if "desktop-searchbar" contains the class "col-2"
  if (searchbar.hasClass('col-5')) {
    $('.icons').css('display', 'none');
  }

  $('.mob-searchIcon').click(() => {
    $('.header-logo').hide();
    $('.icons').hide();
    
    if (searchbar.hasClass('col-5')) {
      searchbar.removeClass('col-5').addClass('col-10');
    } else if (searchbar.hasClass('col-xs-2')) {
      searchbar.removeClass('col-xs-2').addClass('col-xs-10');
    }
  });

  $('.BSoAxsRz9Ln9ikcciEOb').click(() => {
    $('.header-logo').show();
    
    if (searchbar.hasClass('col-10')) {
      searchbar.removeClass('col-10').addClass('col-5');
    } else if (searchbar.hasClass('col-xs-10')) {
      searchbar.removeClass('col-xs-10').addClass('col-xs-2');
      $('.icons').show();
    }
  });

  $('#search-icon').click(() => {
    // removing the logo
    $('.header-logo').hide();
    $('#desktop-searchbar').hide();
    $('.global-globe').hide();
    $('#mobile-nav').show();
    $('#search-icon').hide();
    $('.cancel-search-btn').show();
  });

  $('.cancel-search-btn').click(() => {
    $('.header-logo').show();
    $('.global-globe').show();
    $('#mobile-nav').hide();
    $('#search-icon').show();
    $('.cancel-search-btn').hide();
    $('#desktop-searchbar').show();
  });

  // Define the list of locales and their region links
  const locales = {
    "/en-ca/": "customer.ca.wiley.com",
    "/en-es/": "customer.uk.wiley.com",
    "/en-be/": "customer.uk.wiley.com",
    "/en-sg/": "customer.sg.wiley.com",
    "/en-br/": "customer.wiley.com",
    "/en-fr/": "customer.uk.wiley.com",
    "/en-nz/": "customer.au.wiley.com",
    "/en-it/": "customer.uk.wiley.com",
    "/en-mx/": "customer.wiley.com",
    "/en-au/": "customer.au.wiley.com",
    "/en-ae/": "customer.uk.wiley.com",
    "/en-dk/": "customer.uk.wiley.com",
    "/en-no/": "customer.uk.wiley.com",
    "/en-hk/": "customer.sg.wiley.com",
    "/en-ie/": "customer.uk.wiley.com",
    "/en-se/": "customer.uk.wiley.com",
    "/en-in/": "customer.uk.wiley.com",
    "/en-kr/": "customer.sg.wiley.com",
    "/en-jp/": "customer.sg.wiley.com",
    "/en-nl/": "customer.uk.wiley.com",
    "/en-gb/": "customer.uk.wiley.com"
  };

  // Find the locale in the current URL
  const currentURL = window.location.href;
  let locale = null;
  for (const key in locales) {
    if (currentURL.includes(key)) {
      locale = key;
      break;
    }
  }

  // Find the corresponding region link based on the locale
  let regionLink = null;
  if (locale && locale !== "/en-us/") {
    regionLink = locales[locale];
  }

  // Update the cart icon href attribute
  const cartLink = $('.icons.cart-a'); // Select the cart link
  if (regionLink !== null && !['/en-mx/', '/en-br/'].includes(locale)) {
    // Check if locale is not "/en-mx/" or "/en-br/"
    // Update the href for the cart link to the specified URL
    cartLink.attr('href', `https://${regionLink}/CGI-BIN/lansaweb?procfun+shopcart+shcfn01+funcparms+parmurl(l0760):https%3A%2F%2Fwww.wiley.com+parmhybrs(a0010):Y`);
  }

  // Update the href attributes
  const anchorTags = document.querySelectorAll("a[href*='customer.wiley.com']");
  anchorTags.forEach((anchorTag) => {
    const href = anchorTag.getAttribute("href");
    if (href.includes("customer.wiley.com") && regionLink !== null) {
      const updatedHref = href.replace("customer.wiley.com", regionLink);
      anchorTag.setAttribute("href", updatedHref);
    }
  });

  $(document).on('click', '.card, .article-card.vertical', (ev) => {
    const $this = $(ev.currentTarget);
    if ($this.find($(ev.target).closest('a')[0]).length === 0) {
      ev.preventDefault();
      $this.find('a')[0].click();
    }
  });

  // update My account links to insert current URL
  $('a:contains("My account"), #top a[aria-label="Account"]').each((i, el) => {
    const $el = $(el);
    const newHref = $el.attr('href').replace('https%3A%2F%2Fwww.wiley.com%2Fen-us+source', encodeURIComponent(window.location.href));
    $el.attr('href', newHref);
  });

  /* Hybris related tweaks and overrides */
  if (document.getElementById('addToCartModalWnd') !== null) {
    const observer = new MutationObserver(() => {
      $('#addToCartModalWnd button.close').click(() => $('#addToCartModalWnd').modal('hide'));
    });
    observer.observe(document.getElementById('addToCartModalWnd'), { childList: true });
  }

  const params = new URLSearchParams(window.location.search);
  if (params.has('pq')) {
    const pq = params.get('pq').split('|')[0];
    $('#search-bar').val(pq);
  }

  // capture cart total cookie
  const cartTotalCookie = document.cookie
    .split(';')
    .map((cookie) => cookie.trim())
    .filter((cookie) => cookie.trim().substr(0, 25) === 'wileyb2c-cart-total-items');
  if (cartTotalCookie.length > 0) {
    const cartTotal = Number(cartTotalCookie[0].split('=')[1]);
    if (cartTotal > 0) {
      $('#cart-total-badge').show().text(cartTotal);
    }
  }

  // Hybris fixes
  if ($('#qty').val() === '') {
    $('#qty').val(1);
  }

  const segmentButton = document.querySelector('.subheading--link');
  const segmentButtonParent = document.querySelector('.segment-nav-bar__mobile');
  segmentButton.onclick = () => {
    const x = segmentButtonParent.querySelector('.show-hide_ele');
    if (x.style.display === 'none') {
      x.style.display = 'block';
    } else {
      x.style.display = 'none';
    }
  };

  /**
   * @link https://stackoverflow.com/a/70085772/507169
   * calls the function func once within the within time window.
   * this is a debounce function which actually calls the func as
   * opposed to returning a function that would call func.
   *
   * @param func    the function to call
   * @param within  the time window in milliseconds, defaults to 300
   * @param timerId an optional key, defaults to func
   */
  function callOnce(func, within = 300, timerId = null) {
    window.callOnceTimers = window.callOnceTimers || {};
    if (timerId == null) timerId = func;
    let timer = window.callOnceTimers[timerId];
    clearTimeout(timer);
    timer = setTimeout(() => func(), within);
    window.callOnceTimers[timerId] = timer;
  }

  // search auto-suggestion-box
  const suggestionBoxes = $('.auto-suggestion-box');
  suggestionBoxes.each((i, el) => {
    const suggestionBox = $(el);
    const sugList = suggestionBox.find('.suggestion-list');
    const otherList = suggestionBox.find('.other-list');
    const allResultsLink = suggestionBox.find('.see-all-results');
    suggestionBox.siblings('input[type=search]').keyup((ev) => {
      const searchText = encodeURIComponent($(ev.target).val().replace(/^\s+/gm, ''));
      if (searchText.length > 2 && ev.key.match(/^(\w|\s)$/)) {
        callOnce(() => {
          fetch(`/search/autocomplete/SearchBox?term=${searchText}`)
            .then((r) => r.json())
            .then((data) => {
              suggestionBox.show();
              if ('suggestions' in data) {
                sugList.empty();
                data.suggestions.forEach(({ term }) => {
                  const termText = $(`<div>${term}</div>`).text();
                  sugList.append(`<li><a href="/search?pq=${termText}">${term}</a></li>`);
                });
              }
              if ('pages' in data) {
                otherList.empty();
                data.pages.forEach(({ title, url }) => {
                  otherList.append(`<li><a class="other-list-item-link" href="${url}">${title}</a></li>`);
                });
              }
              allResultsLink
                .attr('href', `/search?pq=${searchText}`)
                .show();
            });
        });
      } else {
        suggestionBox.hide();
        sugList.empty();
        otherList.empty();
        allResultsLink.hide();
      }
    });
  });
});